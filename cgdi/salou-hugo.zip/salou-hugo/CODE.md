Code for this project can be found in a [GitLab
repository](https://gitlab.aliens-lyon.fr/hsalou/m1-cgdi-project)
