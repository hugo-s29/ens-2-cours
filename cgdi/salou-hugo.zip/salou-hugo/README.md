# EXPERIMENTS WITH CURVED PN TRIANGLES.

This repository contains a few Python scripts regarding [curved PN
triangles](https://alex.vlachos.com/graphics/CurvedPNTriangles.pdf).

## DEPENDENCIES.

You can find the list of dependencies in `requirements.txt`. Installing them
can be done using the following command.

```bash
pip3 install -r ./requirements.txt
```

## CONTENTS OF THIS REPOSITORY.

**3D FILES.** The `data/` directory contains some `.ply` 3D models with various
resolutions (the number in the file's name indicates the number of vertices of
that 3D model). Those 3D files were produced by Blender. I used the _Standford
PLY_ file format to allow for “per-vertex normals” (PN means _point normals_)
instead of the more common “per-triangle normals.”

**VISUALIZATION.** Some of the scripts (`alpha.py`, `simple.py`) are present
only to visualize the algorithm in the paper. Script `simple.py` shows the
process on a simple triangle. Script `alpha.py` shows how parameter $\alpha$
affects the generated mesh.

**RESULT ON MODELS.**
Script `object.py` applies the algorithm to the chosen PLY file, all of the
computation is done on the CPU using `numpy`. However, one of the most
important part of this algorithm is that it can be ran in a _geometry shader_,
as each triangle is processed independently. Script `opengl_object.py` also
loads a PLY file, but does all the computation inside an OpenGL geometry
shader, so that all the geometry generation can be done on the GPU. Shaders can
be found in the `shaders/` directory.

**OTHER EXAMPLES.** I provide two practical use-cases for curved PN triangles
in this repository: a cloth simulation and marching cubes (with Perlin noise).
Scripts `cloth.py` and `cubes.py` shows the 3D model given to the procedure
(with the computed normals). (Press “Start” when running `cloth.py` to start
the simulation.) Scripts `opengl_cloth.py` and `opengl_cubes.py` work similarly
to their non-`opengl_` counterparts, but uses the previously mentioned geometry
shader.

## USAGE.

```bash
python3 alpha.py
python3 simple.py

python3 object.py data/⟨some file⟩.ply
python3 opengl_object.py data/⟨some file⟩.ply

python3 cloth.py # Do not forget to press “Start”
python3 opengl_cloth.py

python3 cubes.py
python3 opengl_cubes.py
```

## COMMANDS FOR THE OPENGL WINDOWS.

OpenGL-based scripts have a few keybindings.
- Mouse-dragging (left mouse button) rotates
- Mouse-scrolling zooms
- Arrow keys and Mouse-dragging (right mouse button) pans
- Pressing <kbd>W</kbd> toggles the wireframe view
- Pressing <kbd>D</kbd> switches to a “normal” shader (_i.e._ no curved PN
  triangles added _via_ a geometry shader), pressing it again switches back to
  the default one
- Pressing <kbd>S</kbd> takes a screenshot
- Pressing <kbd>P</kbd> prints the current transform (current view matrix,
  current zoom, current pan).

## NORMALS FOR CURVED PN TRIANGLES.

In the original paper, the normals were computed using a quadratic
interpolation:

```math
\vec{n} (u, v, w) := \sum_{i+j+k=2} \vec{n}_{i,j,k} \: u^i \: v^j \: w^k
```

defined as a function $`\vec{n} : \Delta \to \mathbb{R}^3`$ where

```math
\Delta := \{ (u, v, w) \mid u, v, w \ge 0, u + v + w = 1 \}.
```

The reasoning was that a linear normal variation ignored inflections in the
geometry. I have found that, however, the quadratic normal variation did not
hide the triangle as well as the linear one. As a last experiment, I computed
the “exact normal” of the surface using:

```math
\vec{n}(u, v) := \mathrm{normalized}\left(\frac{\partial \vec{b}}{\partial u}(u, v) \times \frac{\partial \vec{b}}{\partial v}(u, v)\right).
```

We can safely ignore parameter $`w`$ as it is exactly $`1 - u - v`$.

I have found that this last method gave results similar to the quadratic normal
one. You can change the method used for computing normals by updating line 8 of
`shaders/shader.geom`.

## FORMATTING.

All of the Python code is formatted using _yapf_ (version 0.43.0) by using the
`format.sh` shell script. (This is not listed in the dependencies as it is not
mandatory to have it to run the scripts.)
